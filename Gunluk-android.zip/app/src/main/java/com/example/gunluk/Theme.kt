package com.example.gunluk

import android.content.Context

data class Palette(
    val bg: Int,
    val card: Int,
    val text: Int,
    val muted: Int,
    val accent: Int,
    val accentSoft: Int,
    val divider: Int
)

object Theme {
    private val LIGHT = Palette(
        bg = 0xFFF6F3EE.toInt(),
        card = 0xFFFFFFFF.toInt(),
        text = 0xFF2E2A26.toInt(),
        muted = 0xFF8C8477.toInt(),
        accent = 0xFF9C6B4F.toInt(),
        accentSoft = 0xFFEFE2D6.toInt(),
        divider = 0xFFE7E0D6.toInt()
    )
    private val DARK = Palette(
        bg = 0xFF201D1A.toInt(),
        card = 0xFF2B2723.toInt(),
        text = 0xFFF1ECE6.toInt(),
        muted = 0xFF9A9188.toInt(),
        accent = 0xFFD2A679.toInt(),
        accentSoft = 0xFF3A332C.toInt(),
        divider = 0xFF3A332C.toInt()
    )

    fun isDark(ctx: Context): Boolean =
        ctx.getSharedPreferences("gunluk", Context.MODE_PRIVATE).getBoolean("dark_mode", false)

    fun setDark(ctx: Context, on: Boolean) {
        ctx.getSharedPreferences("gunluk", Context.MODE_PRIVATE).edit().putBoolean("dark_mode", on).apply()
    }

    fun get(ctx: Context): Palette = if (isDark(ctx)) DARK else LIGHT
}

val MOODS = listOf("😊", "😌", "😐", "😔", "😢", "😡", "😴", "🤩")
