package com.example.gunluk

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class EntryActivity : Activity() {
    private lateinit var db: Db
    private lateinit var pal: Palette
    private lateinit var dreamInput: EditText
    private lateinit var dayInput: EditText
    private lateinit var morningInput: EditText
    private lateinit var noonInput: EditText
    private lateinit var eveningInput: EditText
    private lateinit var photoFrame: FrameLayout
    private lateinit var photoImage: ImageView
    private lateinit var moodRow: LinearLayout

    private var entryId: Long = -1
    private var createdAt: Long = System.currentTimeMillis()
    private var photoPath: String? = null
    private var pendingPhotoFile: File? = null
    private var selectedMood: String? = null
    private val moodButtons = mutableMapOf<String, TextView>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun sectionTitle(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(pal.muted)
        setPadding(0, dp(18), 0, dp(8))
    }

    private fun multilineInput(hint: String): EditText = EditText(this).apply {
        this.hint = hint
        setHintTextColor(pal.muted)
        setTextColor(pal.text)
        textSize = 15f
        minLines = 3
        gravity = Gravity.TOP or Gravity.START
        val d = GradientDrawable(); d.cornerRadius = dp(14).toFloat(); d.setColor(pal.card)
        background = d
        setPadding(dp(16), dp(14), dp(16), dp(14))
    }

    private fun lineInput(hint: String): EditText = EditText(this).apply {
        this.hint = hint
        setHintTextColor(pal.muted)
        setTextColor(pal.text)
        textSize = 14f
        val d = GradientDrawable(); d.cornerRadius = dp(12).toFloat(); d.setColor(pal.card)
        background = d
        setPadding(dp(14), dp(12), dp(14), dp(12))
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        db = Db(this)
        pal = Theme.get(this)
        entryId = intent.getLongExtra("entry_id", -1)

        val root = ScrollView(this)
        root.setBackgroundColor(pal.bg)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(24), dp(48), dp(24), dp(60))
        root.addView(col)

        // Üst bar: geri + tarih/saat (otomatik, düzenlenemez)
        val topRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val back = TextView(this).apply {
            text = "←"; textSize = 22f; setTextColor(pal.text)
            setPadding(0, 0, dp(16), 0)
            setOnClickListener { finish() }
        }
        topRow.addView(back)
        val dateFmt = SimpleDateFormat("d MMMM yyyy", Locale("tr"))
        val timeFmt = SimpleDateFormat("HH:mm", Locale("tr"))
        val dateCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val dateLabel = TextView(this).apply {
            text = dateFmt.format(Date(createdAt))
            textSize = 17f
            setTextColor(pal.text)
        }
        val timeLabel = TextView(this).apply {
            text = timeFmt.format(Date(createdAt))
            textSize = 13f
            setTextColor(pal.muted)
        }
        dateCol.addView(dateLabel); dateCol.addView(timeLabel)
        topRow.addView(dateCol)
        col.addView(topRow)

        // Ruh hali seçici
        col.addView(sectionTitle("Bugün nasılsın?"))
        moodRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        MOODS.forEach { m ->
            val mb = TextView(this).apply {
                text = m
                textSize = 20f
                gravity = Gravity.CENTER
                val d = GradientDrawable(); d.shape = GradientDrawable.OVAL; d.setColor(pal.card)
                background = d
                val size = dp(42)
                val lp = LinearLayout.LayoutParams(size, size); lp.marginEnd = dp(8)
                layoutParams = lp
                setOnClickListener {
                    selectedMood = m
                    renderMoodSelection()
                }
            }
            moodButtons[m] = mb
            moodRow.addView(mb)
        }
        val moodScroll = HorizontalScrollView(this)
        moodScroll.addView(moodRow)
        col.addView(moodScroll)

        // Rüya
        col.addView(sectionTitle("Rüyan"))
        dreamInput = multilineInput("Uyandığında ne hatırlıyorsun?")
        col.addView(dreamInput)

        // Fotoğraf
        col.addView(sectionTitle("Günün fotoğrafı"))
        photoFrame = FrameLayout(this)
        val frameH = dp(180)
        val frameD = GradientDrawable()
        frameD.cornerRadius = dp(16).toFloat()
        frameD.setColor(pal.card)
        frameD.setStroke(dp(1), pal.divider)
        photoFrame.background = frameD
        photoFrame.layoutParams = LinearLayout.LayoutParams(-1, frameH)

        val camIcon = TextView(this).apply {
            text = "📷"
            textSize = 30f
            gravity = Gravity.CENTER
        }
        val camLp = FrameLayout.LayoutParams(-2, -2); camLp.gravity = Gravity.CENTER
        photoFrame.addView(camIcon, camLp)

        photoImage = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            visibility = View.GONE
        }
        photoFrame.addView(photoImage, FrameLayout.LayoutParams(-1, -1))

        photoFrame.setOnClickListener { openCamera() }
        col.addView(photoFrame)

        // Gün
        col.addView(sectionTitle("Günün nasıl geçti?"))
        dayInput = multilineInput("Bugün neler oldu, neler hissettin?")
        col.addView(dayInput)

        // Yemek
        col.addView(sectionTitle("Ne yedin?"))
        morningInput = lineInput("Sabah")
        val spF1 = Space(this); spF1.layoutParams = LinearLayout.LayoutParams(-1, dp(8))
        noonInput = lineInput("Öğle")
        val spF2 = Space(this); spF2.layoutParams = LinearLayout.LayoutParams(-1, dp(8))
        eveningInput = lineInput("Akşam")
        col.addView(morningInput); col.addView(spF1); col.addView(noonInput); col.addView(spF2); col.addView(eveningInput)

        // Kaydet
        val spSave = Space(this); spSave.layoutParams = LinearLayout.LayoutParams(-1, dp(28))
        col.addView(spSave)
        val saveBtn = Button(this).apply {
            text = "Kaydet"
            isAllCaps = false
            setTextColor(Color.WHITE)
            val d = GradientDrawable(); d.cornerRadius = dp(16).toFloat(); d.setColor(pal.accent)
            background = d
            setPadding(dp(24), dp(16), dp(24), dp(16))
            setOnClickListener { save() }
        }
        col.addView(saveBtn)

        setContentView(root)

        if (entryId != -1L) loadExisting()
        renderMoodSelection()
    }

    private fun renderMoodSelection() {
        moodButtons.forEach { (m, view) ->
            val d = GradientDrawable()
            d.shape = GradientDrawable.OVAL
            if (m == selectedMood) {
                d.setColor(pal.accent)
            } else {
                d.setColor(pal.card)
            }
            view.background = d
        }
    }

    private fun loadExisting() {
        val e = db.get(entryId) ?: return
        createdAt = e.createdAt
        selectedMood = e.mood
        dreamInput.setText(e.dream)
        dayInput.setText(e.dayText)
        morningInput.setText(e.foodMorning)
        noonInput.setText(e.foodNoon)
        eveningInput.setText(e.foodEvening)
        photoPath = e.photoPath
        if (!photoPath.isNullOrEmpty() && File(photoPath!!).exists()) {
            showPhoto(photoPath!!)
        }
    }

    private fun openCamera() {
        val dir = File(filesDir, "fotograflar").apply { mkdirs() }
        val file = File(dir, "gun_${System.currentTimeMillis()}.jpg")
        pendingPhotoFile = file
        val uri: Uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)

        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        intent.putExtra(MediaStore.EXTRA_OUTPUT, uri)
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        // Ön kamerayı tercih et (çoğu kamera uygulamasında çalışır, garanti değildir)
        intent.putExtra("android.intent.extras.CAMERA_FACING", 1)
        intent.putExtra("android.intent.extras.LENS_FACING_FRONT", 1)
        intent.putExtra("android.intent.extra.USE_FRONT_CAMERA", true)
        try {
            startActivityForResult(intent, 100)
        } catch (ex: Exception) {
            Toast.makeText(this, "Kamera açılamadı.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == Activity.RESULT_OK) {
            pendingPhotoFile?.let {
                photoPath = it.absolutePath
                showPhoto(it.absolutePath)
            }
        }
    }

    private fun showPhoto(path: String) {
        val bmp = BitmapFactory.decodeFile(path) ?: return
        photoImage.setImageBitmap(bmp)
        photoImage.visibility = View.VISIBLE
    }

    private fun save() {
        val e = Entry(
            id = if (entryId == -1L) 0 else entryId,
            createdAt = createdAt,
            mood = selectedMood,
            dream = dreamInput.text.toString(),
            dayText = dayInput.text.toString(),
            foodMorning = morningInput.text.toString(),
            foodNoon = noonInput.text.toString(),
            foodEvening = eveningInput.text.toString(),
            photoPath = photoPath
        )
        if (entryId == -1L) db.insert(e) else db.update(e)
        Toast.makeText(this, "Kaydedildi", Toast.LENGTH_SHORT).show()
        finish()
    }
}
