package com.example.gunluk

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class CalendarActivity : Activity() {
    private lateinit var db: Db
    private lateinit var pal: Palette
    private lateinit var grid: LinearLayout
    private lateinit var monthLabel: TextView
    private val month: Calendar = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1) }
    private val monthFmt = SimpleDateFormat("MMMM yyyy", Locale("tr"))

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        db = Db(this)
        pal = Theme.get(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pal.bg)
            setPadding(dp(20), dp(48), dp(20), dp(20))
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(TextView(this).apply {
            text = "←"; textSize = 22f; setTextColor(pal.text)
            setPadding(0, 0, dp(16), 0)
            setOnClickListener { finish() }
        })
        top.addView(TextView(this).apply { text = "Takvim"; textSize = 22f; setTextColor(pal.text) })
        root.addView(top)

        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        nav.setPadding(0, dp(20), 0, dp(12))
        nav.addView(TextView(this).apply {
            text = "‹"; textSize = 28f; setTextColor(pal.text); setPadding(dp(16), 0, dp(16), 0)
            setOnClickListener { month.add(Calendar.MONTH, -1); render() }
        })
        monthLabel = TextView(this).apply { textSize = 17f; setTextColor(pal.text); gravity = Gravity.CENTER }
        nav.addView(monthLabel, LinearLayout.LayoutParams(0, -2, 1f))
        nav.addView(TextView(this).apply {
            text = "›"; textSize = 28f; setTextColor(pal.text); setPadding(dp(16), 0, dp(16), 0)
            setOnClickListener { month.add(Calendar.MONTH, 1); render() }
        })
        root.addView(nav)

        val names = listOf("Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz")
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        names.forEach { n ->
            head.addView(TextView(this).apply {
                text = n; textSize = 12f; setTextColor(pal.muted); gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(head)

        grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(grid)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        monthLabel.text = monthFmt.format(month.time).replaceFirstChar { it.uppercase() }
        grid.removeAllViews()

        val byDay = db.all().groupBy { Db.dayKey(it.createdAt) }
        val daysInMonth = month.getActualMaximum(Calendar.DAY_OF_MONTH)
        // Pazartesi = 0
        val offset = (month.get(Calendar.DAY_OF_WEEK) + 5) % 7
        val todayKey = Db.dayKey(System.currentTimeMillis())

        var day = 1 - offset
        while (day <= daysInMonth) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (i in 0 until 7) {
                val cell = TextView(this).apply { gravity = Gravity.CENTER; textSize = 15f }
                if (day in 1..daysInMonth) {
                    val c = (month.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, day) }
                    val key = Db.dayKey(c.timeInMillis)
                    val list = byDay[key]
                    cell.text = day.toString()
                    val d = GradientDrawable(); d.shape = GradientDrawable.OVAL
                    when {
                        list != null -> { d.setColor(pal.accent); cell.setTextColor(Color.WHITE) }
                        key == todayKey -> { d.setColor(pal.accentSoft); cell.setTextColor(pal.text) }
                        else -> { d.setColor(Color.TRANSPARENT); cell.setTextColor(pal.text) }
                    }
                    cell.background = d
                    cell.setOnClickListener {
                        when {
                            list != null -> startActivity(
                                Intent(this, EntryActivity::class.java).putExtra("entry_id", list.first().id)
                            )
                            key == todayKey -> startActivity(Intent(this, EntryActivity::class.java))
                            else -> Toast.makeText(this, "Bu güne ait sayfa yok", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
                val lp = LinearLayout.LayoutParams(0, dp(46), 1f)
                lp.setMargins(dp(2), dp(2), dp(2), dp(2))
                row.addView(cell, lp)
                day++
            }
            grid.addView(row)
        }
    }
}
