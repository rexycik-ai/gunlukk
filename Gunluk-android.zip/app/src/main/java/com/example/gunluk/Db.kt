package com.example.gunluk

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Entry(
    val id: Long,
    val createdAt: Long,
    val mood: String?,
    val dream: String,
    val dayText: String,
    val foodMorning: String,
    val foodNoon: String,
    val foodEvening: String,
    val photoPath: String?
)

class Db(ctx: Context) : SQLiteOpenHelper(ctx, "gunluk.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE entries(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at INTEGER,
                mood TEXT,
                dream TEXT,
                day_text TEXT,
                food_morning TEXT,
                food_noon TEXT,
                food_evening TEXT,
                photo_path TEXT
            )"""
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldV: Int, newV: Int) {}

    fun insert(e: Entry): Long {
        val v = ContentValues().apply {
            put("created_at", e.createdAt)
            put("mood", e.mood)
            put("dream", e.dream)
            put("day_text", e.dayText)
            put("food_morning", e.foodMorning)
            put("food_noon", e.foodNoon)
            put("food_evening", e.foodEvening)
            put("photo_path", e.photoPath)
        }
        return writableDatabase.insert("entries", null, v)
    }

    fun update(e: Entry) {
        val v = ContentValues().apply {
            put("mood", e.mood)
            put("dream", e.dream)
            put("day_text", e.dayText)
            put("food_morning", e.foodMorning)
            put("food_noon", e.foodNoon)
            put("food_evening", e.foodEvening)
            put("photo_path", e.photoPath)
        }
        writableDatabase.update("entries", v, "id=?", arrayOf(e.id.toString()))
    }

    fun delete(id: Long) {
        writableDatabase.delete("entries", "id=?", arrayOf(id.toString()))
    }

    fun get(id: Long): Entry? {
        readableDatabase.rawQuery(
            "SELECT id, created_at, mood, dream, day_text, food_morning, food_noon, food_evening, photo_path " +
                    "FROM entries WHERE id=?", arrayOf(id.toString())
        ).use { c ->
            if (c.moveToFirst()) return readRow(c)
        }
        return null
    }

    fun all(): List<Entry> {
        val out = mutableListOf<Entry>()
        readableDatabase.rawQuery(
            "SELECT id, created_at, mood, dream, day_text, food_morning, food_noon, food_evening, photo_path " +
                    "FROM entries ORDER BY created_at DESC", null
        ).use { c ->
            while (c.moveToNext()) out += readRow(c)
        }
        return out
    }

    private fun readRow(c: android.database.Cursor): Entry = Entry(
        id = c.getLong(0),
        createdAt = c.getLong(1),
        mood = c.getString(2),
        dream = c.getString(3) ?: "",
        dayText = c.getString(4) ?: "",
        foodMorning = c.getString(5) ?: "",
        foodNoon = c.getString(6) ?: "",
        foodEvening = c.getString(7) ?: "",
        photoPath = c.getString(8)
    )
}
