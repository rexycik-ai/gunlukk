package com.example.gunluk

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.util.Calendar

data class Entry(
    val id: Long,
    val createdAt: Long,
    val mood: String?,
    val dream: String,
    val dayText: String,
    val foodMorning: String,
    val foodNoon: String,
    val foodEvening: String,
    val photoPath: String?,
    val sleep: String = "",
    val water: Int = 0,
    val exercise: String = "",
    val spending: String = "",
    val tags: String = "",
    val dreamAt: Long = 0,
    val dayAt: Long = 0
)

class Db(ctx: Context) : SQLiteOpenHelper(ctx, "gunluk.db", null, 3) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE entries(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at INTEGER,
                mood TEXT,
                dream TEXT,
                day_text TEXT,
                food_morning TEXT,
                food_noon TEXT,
                food_evening TEXT,
                photo_path TEXT,
                sleep TEXT DEFAULT '',
                water INTEGER DEFAULT 0,
                exercise TEXT DEFAULT '',
                spending TEXT DEFAULT '',
                tags TEXT DEFAULT '',
                dream_at INTEGER DEFAULT 0,
                day_at INTEGER DEFAULT 0
            )"""
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldV: Int, newV: Int) {
        if (oldV < 2) {
            db.execSQL("ALTER TABLE entries ADD COLUMN sleep TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE entries ADD COLUMN water INTEGER DEFAULT 0")
            db.execSQL("ALTER TABLE entries ADD COLUMN exercise TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE entries ADD COLUMN spending TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE entries ADD COLUMN tags TEXT DEFAULT ''")
        }
        if (oldV < 3) {
            db.execSQL("ALTER TABLE entries ADD COLUMN dream_at INTEGER DEFAULT 0")
            db.execSQL("ALTER TABLE entries ADD COLUMN day_at INTEGER DEFAULT 0")
        }
    }

    private fun values(e: Entry, withDate: Boolean): ContentValues = ContentValues().apply {
        if (withDate) put("created_at", e.createdAt)
        put("mood", e.mood)
        put("dream", e.dream)
        put("day_text", e.dayText)
        put("food_morning", e.foodMorning)
        put("food_noon", e.foodNoon)
        put("food_evening", e.foodEvening)
        put("photo_path", e.photoPath)
        put("sleep", e.sleep)
        put("water", e.water)
        put("exercise", e.exercise)
        put("spending", e.spending)
        put("tags", e.tags)
        put("dream_at", e.dreamAt)
        put("day_at", e.dayAt)
    }

    fun insert(e: Entry): Long = writableDatabase.insert("entries", null, values(e, true))

    fun update(e: Entry) {
        writableDatabase.update("entries", values(e, false), "id=?", arrayOf(e.id.toString()))
    }

    fun delete(id: Long) {
        writableDatabase.delete("entries", "id=?", arrayOf(id.toString()))
    }

    private val cols = "id, created_at, mood, dream, day_text, food_morning, food_noon, food_evening, " +
            "photo_path, sleep, water, exercise, spending, tags, dream_at, day_at"

    fun get(id: Long): Entry? {
        readableDatabase.rawQuery("SELECT $cols FROM entries WHERE id=?", arrayOf(id.toString())).use { c ->
            if (c.moveToFirst()) return readRow(c)
        }
        return null
    }

    fun all(): List<Entry> {
        val out = mutableListOf<Entry>()
        readableDatabase.rawQuery("SELECT $cols FROM entries ORDER BY created_at DESC", null).use { c ->
            while (c.moveToNext()) out += readRow(c)
        }
        return out
    }

    /** Metin, rüya, yemek, egzersiz ve etiketlerde arar (büyük/küçük harf duyarsız). */
    fun search(query: String): List<Entry> {
        val q = query.trim().removePrefix("#").lowercase(java.util.Locale("tr"))
        if (q.isEmpty()) return all()
        return all().filter { e ->
            listOf(e.dream, e.dayText, e.foodMorning, e.foodNoon, e.foodEvening, e.exercise, e.tags)
                .any { it.lowercase(java.util.Locale("tr")).contains(q) }
        }
    }

    /** Bugünden (veya bugün yazılmadıysa dünden) geriye doğru ardışık gün sayısı. */
    fun streak(): Int {
        val days = all().map { dayKey(it.createdAt) }.toSet()
        val cal = Calendar.getInstance()
        if (!days.contains(dayKey(cal.timeInMillis))) cal.add(Calendar.DAY_OF_YEAR, -1)
        var n = 0
        while (days.contains(dayKey(cal.timeInMillis))) {
            n++
            cal.add(Calendar.DAY_OF_YEAR, -1)
        }
        return n
    }

    private fun readRow(c: android.database.Cursor): Entry = Entry(
        id = c.getLong(0),
        createdAt = c.getLong(1),
        mood = c.getString(2),
        dream = c.getString(3) ?: "",
        dayText = c.getString(4) ?: "",
        foodMorning = c.getString(5) ?: "",
        foodNoon = c.getString(6) ?: "",
        foodEvening = c.getString(7) ?: "",
        photoPath = c.getString(8),
        sleep = c.getString(9) ?: "",
        water = c.getInt(10),
        exercise = c.getString(11) ?: "",
        spending = c.getString(12) ?: "",
        tags = c.getString(13) ?: "",
        dreamAt = c.getLong(14),
        dayAt = c.getLong(15)
    )

    companion object {
        fun dayKey(ms: Long): Int {
            val c = Calendar.getInstance().apply { timeInMillis = ms }
            return c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR)
        }
    }
}
