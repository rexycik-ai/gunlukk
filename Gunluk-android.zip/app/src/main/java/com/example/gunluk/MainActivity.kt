package com.example.gunluk

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.os.Build
import android.text.Editable
import android.text.TextWatcher
import java.io.File
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var db: Db
    private lateinit var pal: Palette
    private lateinit var list: ListView
    private lateinit var empty: TextView
    private lateinit var streakLabel: TextView
    private lateinit var bell: TextView
    private lateinit var searchInput: EditText
    private var query = ""
    private val fmt = SimpleDateFormat("d MMMM yyyy, EEEE", Locale("tr"))

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        db = Db(this)
        pal = Theme.get(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pal.bg)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(28), dp(48), dp(20), dp(20))
        }
        val title = TextView(this).apply {
            text = "Günlüğüm"
            textSize = 24f
            setTextColor(pal.text)
        }
        val titleCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleCol.addView(title)
        streakLabel = TextView(this).apply { textSize = 13f; setTextColor(pal.muted) }
        titleCol.addView(streakLabel)
        header.addView(titleCol, LinearLayout.LayoutParams(0, -2, 1f))

        fun iconBtn(t: String, onTap: () -> Unit) = TextView(this).apply {
            text = t; textSize = 20f
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setOnClickListener { onTap() }
        }
        header.addView(iconBtn("📅") { startActivity(Intent(this, CalendarActivity::class.java)) })
        bell = iconBtn("🔔") { toggleReminder() }
        header.addView(bell)

        val darkBtn = TextView(this).apply {
            text = if (Theme.isDark(this@MainActivity)) "☀️" else "🌙"
            textSize = 20f
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setOnClickListener {
                Theme.setDark(this@MainActivity, !Theme.isDark(this@MainActivity))
                recreate()
            }
        }
        header.addView(darkBtn)
        root.addView(header)

        searchInput = EditText(this).apply {
            hint = "Ara: kelime veya #etiket"
            setHintTextColor(pal.muted)
            setTextColor(pal.text)
            textSize = 14f
            isSingleLine = true
            val d = GradientDrawable(); d.cornerRadius = dp(14).toFloat(); d.setColor(pal.card)
            background = d
            setPadding(dp(16), dp(10), dp(16), dp(10))
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { query = s?.toString() ?: ""; refresh() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        val searchLp = LinearLayout.LayoutParams(-1, -2)
        searchLp.setMargins(dp(20), 0, dp(20), dp(12))
        root.addView(searchInput, searchLp)

        empty = TextView(this).apply {
            text = "Henüz bir sayfan yok.\nSağ alttaki + ile ilk günlüğünü yaz."
            textSize = 15f
            setTextColor(pal.muted)
            gravity = Gravity.CENTER
            setPadding(dp(40), dp(80), dp(40), 0)
        }
        root.addView(empty)

        list = ListView(this)
        list.divider = null
        list.dividerHeight = dp(10)
        list.setPadding(dp(16), 0, dp(16), dp(100))
        list.clipToPadding = false
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        // Sağ altta yeni sayfa butonu
        val frame = FrameLayout(this)
        frame.addView(root, FrameLayout.LayoutParams(-1, -1))
        val addBtn = TextView(this).apply {
            text = "+"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            val d = GradientDrawable(); d.shape = GradientDrawable.OVAL; d.setColor(pal.accent)
            background = d
            elevation = dp(6).toFloat()
        }
        val size = dp(64)
        val lp = FrameLayout.LayoutParams(size, size)
        lp.gravity = Gravity.BOTTOM or Gravity.END
        lp.rightMargin = dp(24); lp.bottomMargin = dp(32)
        addBtn.layoutParams = lp
        addBtn.setOnClickListener {
            startActivity(Intent(this, EntryActivity::class.java))
        }
        frame.addView(addBtn)

        setContentView(frame)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val entries = if (query.isBlank()) db.all() else db.search(query)
        val n = db.streak()
        streakLabel.text = if (n > 0) "🔥 $n günlük seri" else "Bugün yazarak seriye başla"
        bell.text = if (Reminder.isOn(this)) "🔔" else "🔕"
        empty.text = if (query.isBlank()) "Henüz bir sayfan yok.\nSağ alttaki + ile ilk günlüğünü yaz." else "Sonuç bulunamadı."
        empty.visibility = if (entries.isEmpty()) View.VISIBLE else View.GONE
        list.adapter = object : ArrayAdapter<Entry>(this, 0, entries) {
            override fun getView(pos: Int, convertView: View?, parent: ViewGroup): View {
                val entry = getItem(pos)!!
                val card = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(18), dp(16), dp(18), dp(16))
                    val d = GradientDrawable(); d.cornerRadius = dp(18).toFloat(); d.setColor(pal.card)
                    background = d
                }
                val top = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
                val dateLabel = TextView(this@MainActivity).apply {
                    text = fmt.format(Date(entry.createdAt))
                    textSize = 13f
                    setTextColor(pal.muted)
                }
                top.addView(dateLabel, LinearLayout.LayoutParams(0, -2, 1f))
                if (!entry.mood.isNullOrEmpty()) {
                    top.addView(TextView(this@MainActivity).apply { text = entry.mood; textSize = 18f })
                }
                card.addView(top)

                val snippetSource = if (entry.dayText.isNotBlank()) entry.dayText else entry.dream
                val snippet = TextView(this@MainActivity).apply {
                    text = if (snippetSource.isBlank()) "(boş sayfa)" else snippetSource
                    textSize = 15f
                    setTextColor(pal.text)
                    maxLines = 2
                    setPadding(0, dp(8), 0, 0)
                }
                card.addView(snippet)

                val extras = mutableListOf<String>()
                if (entry.sleep.isNotBlank()) extras += "😴 ${entry.sleep} sa"
                if (entry.water > 0) extras += "💧 ${entry.water}"
                if (entry.exercise.isNotBlank()) extras += "🏃 ${entry.exercise}"
                if (entry.spending.isNotBlank()) extras += "₺${entry.spending}"
                if (extras.isNotEmpty()) card.addView(TextView(this@MainActivity).apply {
                    text = extras.joinToString("  ·  "); textSize = 12f; setTextColor(pal.muted)
                    setPadding(0, dp(8), 0, 0)
                })
                if (entry.tags.isNotBlank()) card.addView(TextView(this@MainActivity).apply {
                    text = entry.tags.split(",").joinToString(" ") { "#" + it.trim() }
                    textSize = 12f; setTextColor(pal.accent)
                    setPadding(0, dp(6), 0, 0)
                })

                val actions = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.END
                    setPadding(0, dp(8), 0, 0)
                }
                actions.addView(TextView(this@MainActivity).apply {
                    text = "✏️ Düzenle"; textSize = 13f; setTextColor(pal.accent)
                    setPadding(dp(12), dp(6), dp(12), dp(6))
                    setOnClickListener { openEntry(entry.id) }
                })
                actions.addView(TextView(this@MainActivity).apply {
                    text = "🗑 Sil"; textSize = 13f; setTextColor(pal.muted)
                    setPadding(dp(12), dp(6), dp(0), dp(6))
                    setOnClickListener { confirmDelete(entry) }
                })
                card.addView(actions)

                card.setOnClickListener {
                    val i = Intent(this@MainActivity, EntryActivity::class.java)
                    i.putExtra("entry_id", entry.id)
                    startActivity(i)
                }
                return card
            }
        }
    }

    private fun openEntry(id: Long) {
        val i = Intent(this, EntryActivity::class.java)
        i.putExtra("entry_id", id)
        startActivity(i)
    }

    private fun confirmDelete(e: Entry) {
        AlertDialog.Builder(this)
            .setTitle("Sayfayı sil")
            .setMessage("${fmt.format(Date(e.createdAt))} tarihli sayfa kalıcı olarak silinecek. Emin misin?")
            .setPositiveButton("Sil") { _, _ ->
                e.photoPath?.let { File(it).delete() }
                db.delete(e.id)
                refresh()
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    private fun toggleReminder() {
        if (Reminder.isOn(this)) {
            Reminder.disable(this)
            Toast.makeText(this, "Hatırlatıcı kapatıldı", Toast.LENGTH_SHORT).show()
            refresh()
            return
        }
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 200)
        }
        TimePickerDialog(this, { _, h, m ->
            Reminder.enable(this, h, m)
            Toast.makeText(this, "Her gün %02d:%02d'de hatırlatılacak".format(h, m), Toast.LENGTH_SHORT).show()
            refresh()
        }, Reminder.hour(this), Reminder.minute(this), true).show()
    }
}
