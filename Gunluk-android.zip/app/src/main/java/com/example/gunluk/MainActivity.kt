package com.example.gunluk

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var db: Db
    private lateinit var pal: Palette
    private lateinit var list: ListView
    private lateinit var empty: TextView
    private val fmt = SimpleDateFormat("d MMMM yyyy, EEEE", Locale("tr"))

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        db = Db(this)
        pal = Theme.get(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pal.bg)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(28), dp(48), dp(20), dp(20))
        }
        val title = TextView(this).apply {
            text = "Günlüğüm"
            textSize = 24f
            setTextColor(pal.text)
        }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))

        val darkBtn = TextView(this).apply {
            text = if (Theme.isDark(this@MainActivity)) "☀️" else "🌙"
            textSize = 20f
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setOnClickListener {
                Theme.setDark(this@MainActivity, !Theme.isDark(this@MainActivity))
                recreate()
            }
        }
        header.addView(darkBtn)
        root.addView(header)

        empty = TextView(this).apply {
            text = "Henüz bir sayfan yok.\nSağ alttaki + ile ilk günlüğünü yaz."
            textSize = 15f
            setTextColor(pal.muted)
            gravity = Gravity.CENTER
            setPadding(dp(40), dp(80), dp(40), 0)
        }
        root.addView(empty)

        list = ListView(this)
        list.divider = null
        list.dividerHeight = dp(10)
        list.setPadding(dp(16), 0, dp(16), dp(100))
        list.clipToPadding = false
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        // Sağ altta yeni sayfa butonu
        val frame = FrameLayout(this)
        frame.addView(root, FrameLayout.LayoutParams(-1, -1))
        val addBtn = TextView(this).apply {
            text = "+"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            val d = GradientDrawable(); d.shape = GradientDrawable.OVAL; d.setColor(pal.accent)
            background = d
            elevation = dp(6).toFloat()
        }
        val size = dp(64)
        val lp = FrameLayout.LayoutParams(size, size)
        lp.gravity = Gravity.BOTTOM or Gravity.END
        lp.rightMargin = dp(24); lp.bottomMargin = dp(32)
        addBtn.layoutParams = lp
        addBtn.setOnClickListener {
            startActivity(Intent(this, EntryActivity::class.java))
        }
        frame.addView(addBtn)

        setContentView(frame)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val entries = db.all()
        empty.visibility = if (entries.isEmpty()) View.VISIBLE else View.GONE
        list.adapter = object : ArrayAdapter<Entry>(this, 0, entries) {
            override fun getView(pos: Int, convertView: View?, parent: ViewGroup): View {
                val entry = getItem(pos)!!
                val card = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(18), dp(16), dp(18), dp(16))
                    val d = GradientDrawable(); d.cornerRadius = dp(18).toFloat(); d.setColor(pal.card)
                    background = d
                }
                val top = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
                val dateLabel = TextView(this@MainActivity).apply {
                    text = fmt.format(Date(entry.createdAt))
                    textSize = 13f
                    setTextColor(pal.muted)
                }
                top.addView(dateLabel, LinearLayout.LayoutParams(0, -2, 1f))
                if (!entry.mood.isNullOrEmpty()) {
                    top.addView(TextView(this@MainActivity).apply { text = entry.mood; textSize = 18f })
                }
                card.addView(top)

                val snippetSource = if (entry.dayText.isNotBlank()) entry.dayText else entry.dream
                val snippet = TextView(this@MainActivity).apply {
                    text = if (snippetSource.isBlank()) "(boş sayfa)" else snippetSource
                    textSize = 15f
                    setTextColor(pal.text)
                    maxLines = 2
                    setPadding(0, dp(8), 0, 0)
                }
                card.addView(snippet)

                card.setOnClickListener {
                    val i = Intent(this@MainActivity, EntryActivity::class.java)
                    i.putExtra("entry_id", entry.id)
                    startActivity(i)
                }
                return card
            }
        }
    }
}
